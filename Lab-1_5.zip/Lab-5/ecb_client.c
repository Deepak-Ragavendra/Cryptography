/*
 * Cryptography Client with Padding Support (Windows)
 * Handles variable-length plaintext with automatic padding
 * Compile: gcc client_padded.c -o client_padded -lws2_32
 */

#include <stdio.h>
#include <Winsock2.h>
#include <time.h>
#include <string.h>
#pragma comment(lib, "Ws2_32.lib")

#define BLOCK_SIZE 8
#define MAX_PLAINTEXT 1024

void pad_plaintext(int* plaintext, int* length) {
    int original_length = *length;
    
    int padding_needed = BLOCK_SIZE - (original_length % BLOCK_SIZE);
    if (padding_needed == BLOCK_SIZE) {
        padding_needed = 0;
    }
    for (int i = 0; i < padding_needed; i++) {
        plaintext[original_length + i] = 0;
    }
    *length = original_length + padding_needed;
    printf("\n[PADDING INFO]\n");
    printf("Original length: %d bits\n", original_length);
    printf("Padding added: %d bits\n", padding_needed);
    printf("Final length: %d bits (%d blocks)\n", *length, *length / BLOCK_SIZE);
}

void encrypt_block(int* plaintext_block, int* key, int* cipher_block) {
    for (int i = 0; i < BLOCK_SIZE; i++) {
        cipher_block[i] = plaintext_block[i] ^ key[i];
    }
}

int main() {
    clock_t start = clock();
    WSADATA wsadata;
    SOCKET socketstatus;
    struct sockaddr_in clientSocket;

    // Winsock init
    if (WSAStartup(MAKEWORD(2, 2), &wsadata) != 0) {
        printf("WSAStartup Failed\n");
        return 0;
    }

    // 8-bit key (now properly sized for block size)
    int key[] = {1, 0, 1, 0, 1, 1, 0, 0};
    
    int plaintext[MAX_PLAINTEXT];
    int length;

    printf("==================================================\n");
    printf("  CRYPTOGRAPHY CLIENT WITH PADDING SUPPORT\n");
    printf("==================================================\n");
    printf("Block Size: %d bits\n", BLOCK_SIZE);
    printf("Key: ");
    for (int i = 0; i < BLOCK_SIZE; i++) {
        printf("%d", key[i]);
    }
    printf("\n\n");

    // Input plaintext length
    printf("Enter the number of bits in plaintext: ");
    scanf("%d", &length);

    if (length <= 0 || length > MAX_PLAINTEXT) {
        printf("Invalid length! (1-%d)\n", MAX_PLAINTEXT);
        WSACleanup();
        return 0;
    }

    // Input plaintext bits
    printf("Enter the plaintext (%d bits, space-separated):\n", length);
    for (int i = 0; i < length; i++) {
        scanf("%d", &plaintext[i]);
        if (plaintext[i] != 0 && plaintext[i] != 1) {
            printf("Invalid bit! Only 0 or 1 allowed.\n");
            WSACleanup();
            return 0;
        }
    }

    printf("\n[ORIGINAL PLAINTEXT]\n");
    printf("Plaintext (%d bits): ", length);
    for (int i = 0; i < length; i++) {
        printf("%d", plaintext[i]);
    }
    printf("\n");

    // Apply padding
    int original_length = length;
    pad_plaintext(plaintext, &length);

    printf("\n[PADDED PLAINTEXT]\n");
    printf("Padded plaintext (%d bits): ", length);
    for (int i = 0; i < length; i++) {
        printf("%d", plaintext[i]);
    }
    printf("\n");

    // Calculate number of blocks
    int num_blocks = length / BLOCK_SIZE;
    int cipher[MAX_PLAINTEXT];

    printf("\n[ENCRYPTION PROCESS]\n");
    printf("Number of blocks: %d\n", num_blocks);
    printf("--------------------------------------------------\n");

    // Encrypt each block
    for (int block = 0; block < num_blocks; block++) {
        int block_start = block * BLOCK_SIZE;
        
        printf("Block %d:\n", block + 1);
        printf("  Plaintext:  ");
        for (int i = 0; i < BLOCK_SIZE; i++) {
            printf("%d", plaintext[block_start + i]);
        }
        printf("\n");
        
        // Encrypt this block
        encrypt_block(&plaintext[block_start], key, &cipher[block_start]);
        
        printf("  Ciphertext: ");
        for (int i = 0; i < BLOCK_SIZE; i++) {
            printf("%d", cipher[block_start + i]);
        }
        printf("\n\n");
    }

    // Display final ciphertext
    printf("==================================================\n");
    printf("[FINAL CIPHERTEXT]\n");
    printf("Complete ciphertext (%d bits): ", length);
    for (int i = 0; i < length; i++) {
        printf("%d", cipher[i]);
    }
    printf("\n");
    printf("==================================================\n\n");

    // Socket creation
    socketstatus = socket(AF_INET, SOCK_STREAM, 0);
    if (socketstatus == INVALID_SOCKET) {
        printf("Socket creation failed\n");
        WSACleanup();
        return 0;
    }

    clientSocket.sin_family = AF_INET;
    clientSocket.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
    clientSocket.sin_port = htons(4000);

    printf("[NETWORK COMMUNICATION]\n");
    if (connect(socketstatus, (struct sockaddr*)&clientSocket, sizeof(clientSocket)) == SOCKET_ERROR) {
        printf("Connection Failed - Make sure server is running!\n");
        closesocket(socketstatus);
        WSACleanup();
        return 0;
    }

    printf("✅ Connected to Server\n");

    // Send metadata: original length, padded length, number of blocks
    send(socketstatus, (char*)&original_length, sizeof(int), 0);
    send(socketstatus, (char*)&length, sizeof(int), 0);
    send(socketstatus, (char*)&num_blocks, sizeof(int), 0);

    // Send cipher
    send(socketstatus, (char*)cipher, length * sizeof(int), 0);

    printf("✅ Ciphertext sent successfully\n");
    printf("   - Original length: %d bits\n", original_length);
    printf("   - Padded length: %d bits\n", length);
    printf("   - Blocks sent: %d\n", num_blocks);

    closesocket(socketstatus);
    WSACleanup();

    clock_t end = clock();
    double cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

    printf("\n[PERFORMANCE]\n");
    printf("Time taken: %.6f seconds\n", cpu_time_used);
    printf("==================================================\n");

    return 0;
}