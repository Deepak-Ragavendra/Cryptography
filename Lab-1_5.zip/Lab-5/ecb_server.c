/*
 * Cryptography Server with Padding Support (Windows)
 * Receives and decrypts padded ciphertext
 * Compile: gcc server_padded.c -o server_padded -lws2_32
 */

#include <stdio.h>
#include <Winsock2.h>
#include <time.h>
#pragma comment(lib, "Ws2_32.lib")

#define BLOCK_SIZE 8
#define MAX_CIPHERTEXT 1024

// XOR decryption for one block (same as encryption for XOR)
void decrypt_block(int* cipher_block, int* key, int* plaintext_block) {
    for (int i = 0; i < BLOCK_SIZE; i++) {
        plaintext_block[i] = cipher_block[i] ^ key[i];
    }
}

int main() {
    WSADATA wsadata;
    SOCKET serversocket, clientsocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrLen = sizeof(clientAddr);

    // Winsock init
    if (WSAStartup(MAKEWORD(2, 2), &wsadata) != 0) {
        printf("WSAStartup Failed\n");
        return 0;
    }

    // 8-bit key (must match client)
    int key[] = {1, 0, 1, 0, 1, 1, 0, 0};

    printf("==================================================\n");
    printf("  CRYPTOGRAPHY SERVER WITH PADDING SUPPORT\n");
    printf("==================================================\n");
    printf("Block Size: %d bits\n", BLOCK_SIZE);
    printf("Key: ");
    for (int i = 0; i < BLOCK_SIZE; i++) {
        printf("%d", key[i]);
    }
    printf("\n");
    printf("Listening on port 4000...\n");
    printf("==================================================\n\n");

    // Create socket
    serversocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serversocket == INVALID_SOCKET) {
        printf("Socket creation failed\n");
        WSACleanup();
        return 0;
    }

    // Bind socket
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.S_un.S_addr = INADDR_ANY;
    serverAddr.sin_port = htons(4000);

    if (bind(serversocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        printf("Bind failed\n");
        closesocket(serversocket);
        WSACleanup();
        return 0;
    }

    // Listen
    if (listen(serversocket, 5) == SOCKET_ERROR) {
        printf("Listen failed\n");
        closesocket(serversocket);
        WSACleanup();
        return 0;
    }

    printf("✅ Server ready - Waiting for client...\n\n");

    while (1) {
        // Accept connection
        clientsocket = accept(serversocket, (struct sockaddr*)&clientAddr, &clientAddrLen);
        if (clientsocket == INVALID_SOCKET) {
            printf("Accept failed\n");
            continue;
        }

        printf("==================================================\n");
        printf("🔗 New client connected!\n");
        printf("==================================================\n");

        clock_t start = clock();

        // Receive metadata
        int original_length, padded_length, num_blocks;
        recv(clientsocket, (char*)&original_length, sizeof(int), 0);
        recv(clientsocket, (char*)&padded_length, sizeof(int), 0);
        recv(clientsocket, (char*)&num_blocks, sizeof(int), 0);

        printf("\n[RECEIVED METADATA]\n");
        printf("Original length: %d bits\n", original_length);
        printf("Padded length: %d bits\n", padded_length);
        printf("Number of blocks: %d\n", num_blocks);
        printf("Padding added: %d bits\n", padded_length - original_length);

        // Receive ciphertext
        int cipher[MAX_CIPHERTEXT];
        recv(clientsocket, (char*)cipher, padded_length * sizeof(int), 0);

        printf("\n[RECEIVED CIPHERTEXT]\n");
        printf("Ciphertext (%d bits): ", padded_length);
        for (int i = 0; i < padded_length; i++) {
            printf("%d", cipher[i]);
        }
        printf("\n");

        // Decrypt
        int plaintext[MAX_CIPHERTEXT];
        
        printf("\n[DECRYPTION PROCESS]\n");
        printf("--------------------------------------------------\n");

        for (int block = 0; block < num_blocks; block++) {
            int block_start = block * BLOCK_SIZE;
            
            printf("Block %d:\n", block + 1);
            printf("  Ciphertext: ");
            for (int i = 0; i < BLOCK_SIZE; i++) {
                printf("%d", cipher[block_start + i]);
            }
            printf("\n");
            
            // Decrypt this block
            decrypt_block(&cipher[block_start], key, &plaintext[block_start]);
            
            printf("  Plaintext:  ");
            for (int i = 0; i < BLOCK_SIZE; i++) {
                printf("%d", plaintext[block_start + i]);
            }
            printf("\n\n");
        }

        // Display padded plaintext
        printf("==================================================\n");
        printf("[DECRYPTED PLAINTEXT (WITH PADDING)]\n");
        printf("Padded plaintext (%d bits): ", padded_length);
        for (int i = 0; i < padded_length; i++) {
            printf("%d", plaintext[i]);
        }
        printf("\n");

        // Remove padding and display original plaintext
        printf("\n[ORIGINAL PLAINTEXT (PADDING REMOVED)]\n");
        printf("Original plaintext (%d bits): ", original_length);
        for (int i = 0; i < original_length; i++) {
            printf("%d", plaintext[i]);
        }
        printf("\n");
        printf("==================================================\n");

        clock_t end = clock();
        double cpu_time_used = ((double)(end - start)) / CLOCKS_PER_SEC;

        printf("\n[PERFORMANCE]\n");
        printf("Time taken: %.6f seconds\n", cpu_time_used);
        printf("==================================================\n");

        printf("\n✅ Client disconnected - Waiting for next client...\n\n");

        closesocket(clientsocket);
    }

    closesocket(serversocket);
    WSACleanup();
    return 0;
}